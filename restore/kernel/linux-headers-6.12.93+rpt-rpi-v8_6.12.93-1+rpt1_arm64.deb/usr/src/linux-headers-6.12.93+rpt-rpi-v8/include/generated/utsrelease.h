#define UTS_RELEASE "6.12.93+rpt-rpi-v8"
